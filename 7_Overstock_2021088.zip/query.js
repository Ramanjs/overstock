export const query = "select * from shoe"
