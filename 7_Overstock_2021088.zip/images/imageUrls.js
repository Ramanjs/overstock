export const mensImages = [
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/b56de370-c5b8-43d3-bbd1-e9c44f4ed247/air-jordan-6-retro-shoes-fjwJgW.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/9c3a7b17-13f3-48da-a681-ff500b46cf6e/air-jordan-5-dj-khaled-shoes-tQrmGS.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/d4e6e2db-2805-4c64-8382-06574e982d5c/zion-2-pf-basketball-shoes-pwN2Q4.png',
]

export const womensImages = [
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/87d7e901-4d08-4456-9d62-07e821aff45b/air-max-90-futura-shoes-x9msLm.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/734229e4-3a86-4194-b142-38bd0015209b/air-force-1-shoes-pK50VL.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/db19f550-c2aa-4515-b5f9-b61384564df9/air-deldon-hoodie-basketball-shoes-L07kGx.png'
]

export const kidsImages = [
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/9e7bc064-d3b7-4f6a-b8d4-2d108e7837a0/air-jordan-1-low-se-older-shoes-kg1hPR.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/5c78ac92-88f6-4a97-ad25-e356d20fea2e/air-jordan-1-retro-high-og-shoe-PLe8kL.png',
  'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/e3b49680-41ba-40a5-9f50-a634eb4db5c3/air-jordan-1-mid-se-older-shoes-7hSWff.png'
]
